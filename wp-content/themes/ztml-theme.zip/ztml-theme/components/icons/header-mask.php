<?php

function render_header_mask()
{
?>
	<div class="header_splahesh">
		<span></span>
		<span></span>
		<span></span>
	</div>
<?php
}
