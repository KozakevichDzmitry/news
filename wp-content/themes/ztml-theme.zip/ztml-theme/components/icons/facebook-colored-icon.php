<?php

function render_facebook_colored_icon()
{
?>
	<svg width="40" height="60" viewBox="0 0 40 60" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path d="M37.3789 33.7481L39.4538 22.89H26.4838V15.8438C26.4838 12.8737 28.295 9.97688 34.1043 9.97688H40V0.733125C40 0.733125 34.6505 0 29.5344 0C18.854 0 11.873 5.20125 11.873 14.6156V22.8919H0V33.75H11.873V60H26.4838V33.75L37.3789 33.7481Z" fill="#4064AC" />
	</svg>
<?php
}
