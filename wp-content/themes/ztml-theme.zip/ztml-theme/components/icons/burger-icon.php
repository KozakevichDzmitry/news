<?php

function render_burger_icon()
{
?>
	<svg width="34" height="34" viewBox="0 0 34 34" fill="none" xmlns="http://www.w3.org/2000/svg">
		<path d="M2 12H25.3333M2 2H32M2 32H25.3333M2 22H32" stroke="#101010" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" />
	</svg>
<?php
}
