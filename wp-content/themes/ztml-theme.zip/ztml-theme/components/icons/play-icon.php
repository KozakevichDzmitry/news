<?php

function render_play_icon()
{
?>
	<img style="width: 10px !important; height: 10px !important; object-fit: contain;" src="<?php echo get_template_directory_uri() . '/assets/images/sidebar-play-icon.png'; ?>"/>
<?php
}
